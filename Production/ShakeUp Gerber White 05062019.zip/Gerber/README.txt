Board Guide
===========
PCB Thickness : 1.6mm ENIG (Immersion Gold)
PCB Layers : 2
Silkscreen Color : Black
Soldermask Color : White

Layers
=====
*.1GKO - Board Dimension
*.2TXT - Drill 
*.3GTP - Solder Paste
*.4GTS - TOP Solder Mask
*.5GTO - TOP Silkscreen
*.6GTL - TOP Copper Layer
*.9GBO - BOTTOM Silkscreen
*.10GBS - BOTTOM Solder Mask
*.11GBL - BOTTOM Copper Layer

